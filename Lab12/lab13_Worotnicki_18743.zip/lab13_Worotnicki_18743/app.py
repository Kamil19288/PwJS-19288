# -*- coding: utf-8 -*-
"""
Created on Wed May 29 10:49:42 2019

@author: Student
"""

import sqlite3 as sql
from flask import Flask,render_template,request,redirect, url_for, Response, session, abort
from flask_login import LoginManager, UserMixin, login_required, login_user, logout_user

app = Flask(__name__)

# config
app.config.update(
 DEBUG = True,
 SECRET_KEY = 'sekretny_klucz'
)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

#model uzytkownika
class User(UserMixin):
 def __init__(self, id):
     self.id = id
     self.name = "user" + str(id)
     self.password = self.name + "_secret"

 def __repr__(self):
  return "%d/%s/%s" % (self.id, self.name,self.password)

#generacja uzytkownikow
users = [User(id) for id in range(1, 10)]





@app.route("/")
def main():
    for i in users:
        print(i.id)
    print(users)
    return render_template('index.html')

@app.route("/dodaj")
@login_required
def new_student():    
 tytul = "Dodaj pracownika"
 return render_template('studentadd.html', tytul = tytul)

@app.route("/login", methods=["GET", "POST"])
def login():
 tytul = 'Zaloguj się'
 if request.method == 'POST':
     username = request.form['username']
     password = request.form['password']
     for user in users:
         if username == user.name:
             if password == username + "_secret":
                 id = username.split('user')[0]
                 user = User(id)
                 login_user(user)
                 return redirect(url_for("main"))
             else:
                 return abort(401)
         else:
             return abort(401)
 else:
     return render_template('formularz_logowania.html', tytul=tytul)

# przeladowanie uzytkownika
@login_manager.user_loader
def load_user(userid):
 return User(userid)


@app.errorhandler(401)
def page_not_found(e):
    tytul="Cos poszlo nie tak..."
    blad="401"
    return render_template('index.html', tytul=tytul)

@app.route("/logout")
@login_required
def logout():
    logout_user()
    tytul="Wylogowanie"
    return render_template('index.html', tytul=tytul)


@app.route('/dbreset', strict_slashes = False)
@login_required
def dbreset():
    conn = sql.connect('database.db')
    print("BD otwarta")
    cur = conn.cursor()
    try:
        cur.execute('DROP TABLE pracownicy')
    except:
        pass
    cur.execute('CREATE TABLE pracownicy (imienazwisko TEXT, nrpracownika TEXT, adres TEXT)')
    print("tabela utworzona")
    print(cur.fetchall())
    cur.execute("INSERT INTO pracownicy (imienazwisko, nrpracownika, adres) VALUES (?,?,?)",('Jeden Drugi','3','ul. Czwarto-Piata 7/13, 24-680 Szostkow'))
    
    cur.execute("INSERT INTO pracownicy (imienazwisko, nrpracownika, adres) VALUES (?,?,?)",('Imie Nazwisko','34543','ul. Przykladowy Adres 2, 11-111 Miasto'))

    cur.execute("INSERT INTO pracownicy (imienazwisko, nrpracownika, adres) VALUES (?,?,?)",('Dzien dobry','1234','ul. Dobrowieczorna 2, 15-000 Dobranoc'))

    print(cur.fetchall())
    
    cur.execute('SELECT * FROM pracownicy')
    print(cur.fetchall())
    conn.commit()
    conn.close()
    msg = "Zresetowano baze danych!"
    return redirect(url_for('main', msg=msg))

@app.route('/addrec', methods = ['POST', 'GET'], strict_slashes = False)
@login_required
def addrec():
    if request.method == 'POST':
        con = sql.connect('database.db')
        try:
            imienazwisko = request.form['imienazwisko']
            nrpracownika = request.form['nrpracownika']
            adres = request.form['adres']
            
            with sql.connect('database.db') as con:
                cur = con.cursor()
                cur.execute("INSERT INTO pracownicy (imienazwisko, nrpracownika, adres) VALUES (?,?,?)",(imienazwisko,nrpracownika,adres))
                con.commit()
                msg = "Rekord zapisany"
            
        except:
            con.rollback()
            msg = "Blad przy dodawaniu rekordu"
            
        finally:
            con.close()
            tytul = "Dodaj studenta"
            return render_template("studentadd.html", msg=msg, tytul = tytul)
        
        
@app.route('/lista')
@login_required
def list(msg = ''):
    print(msg)
    con = sql.connect('database.db')
    con.row_factory = sql.Row
    cur = con.cursor()
    try:
        cur.execute('SELECT *, rowid FROM pracownicy ORDER BY imienazwisko')
        msg = "Odczytano tabele!"
    except:
        msg = "Nie odczytano tabeli!"
    rekordy = cur.fetchall();
    for i in rekordy:
        for j in i:
            print(j)
    
    tytul = u"Lista pracowników"
    return render_template("lista.html",rekordy = rekordy, msg = msg, tytul = tytul)

@app.route('/usun/<rowid>')
@login_required
def delete(rowid):
    con = sql.connect('database.db')
    con.row_factory = sql.Row
    cur = con.cursor()
    try:
        cur.execute('DELETE FROM pracownicy where rowid = ?',(rowid))
        msg = u"Usunięto rekord"
        con.commit()
    except:
        msg = u"Nie usunięto rekordu!"
    return redirect(url_for('list', msg=msg))



	
if __name__=="__main__":
    app.run()